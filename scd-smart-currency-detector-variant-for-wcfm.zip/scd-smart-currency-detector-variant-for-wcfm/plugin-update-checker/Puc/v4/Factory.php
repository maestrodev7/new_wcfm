<?php
if ( !class_exists('SCD_Puc_v4_Factory', false) ):

	class SCD_Puc_v4_Factory extends Puc_v4p6_Factory { }

endif;
