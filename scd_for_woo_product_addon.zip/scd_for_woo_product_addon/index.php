<?php

/*
  Plugin Name:SCD - Smart Currency Detector - For Woocommerce Product Addon 
  Plugin URI: https://gajelabs.com/customprofile
  Description: Make the compatibility between scd and woocommmerce product add-on
  Author: gajelabs
  Author URI: https://gajelabs.com
  Version: 1.2
 */


if (in_array('scd_dokan_marketplace/index.php', apply_filters('active_plugins', get_option('active_plugins'))) ||
    in_array('scd_wcfm_marketplace/index.php', apply_filters('active_plugins', get_option('active_plugins'))) ||
	in_array('scd_wcmp_marketplace/index.php', apply_filters('active_plugins', get_option('active_plugins'))) ||
	in_array('scd-smart-currency-detector-variant-for-wcfm/index.php', apply_filters('active_plugins', get_option('active_plugins'))) ||
	in_array('scd_wcv_marketplace/index.php', apply_filters('active_plugins', get_option('active_plugins'))) ||
	in_array('scd_standard/index.php', apply_filters('active_plugins', get_option('active_plugins'))) ||
        in_array('scd_marketplace_pro/index.php', apply_filters('active_plugins', get_option('active_plugins'))) ){
add_action('wp_enqueue_scripts', 'scd_pao_add_script_to_post');
    
}  else {
   add_action('admin_notices','scd_pao_require');    
}

function scd_pao_require() {
    echo '<h4 style="color:red;">SCD for Woocommerce product add-on require SCD premium variant for WCFM. <a target="__blank" href="https:gajelabs.com">You can get it here</a></h4>';
}

function scd_pao_add_script_to_post() {
    
    wp_enqueue_script("scd-pao-script-js", trailingslashit(plugins_url("", __FILE__)) . "js/scd_pao.js", array("jquery"));
}

// wcfm compatibility with woo product addons
//   do_action( 'woocommerce_product_addons_panel_option_row', isset( $post ) ? $post : null, $product_addons, $loop, $option );
// use to convert  the addons data before display it in create page
add_action( 'woocommerce_product_addons_panel_option_row','scd_wooc_product_addons_panel_option_row',500,4);
function scd_wooc_product_addons_panel_option_row( $post,$product_addons, $loop, $option){
    $vendor_curr= get_user_meta(get_current_user_id(), 'scd-user-currency',true);
    $rate = scd_get_conversion_rate(get_woocommerce_currency(),$vendor_curr);
    ?>
    <script>
        rate = <?php echo $rate;?>;
    
        if(jQuery('.wc-pao-addon-option-price-type:last').val() == 'flat_fee'){
            value = jQuery('.wc_input_price:last').val()*rate;
            jQuery('.wc_input_price:last').val(value.toFixed(2));
        }
    </script>
    <?php

}


// use to convert  the addons data befor save it in database to wc currency
add_filter('woocommerce_product_addons_save_data','scd_woocommerce_product_addons_save_data',100,2);
function scd_woocommerce_product_addons_save_data($data,$i){

    $vendor_curr= get_user_meta(get_current_user_id(), 'scd-user-currency',true);
    $rate = scd_get_conversion_rate(get_woocommerce_currency(),$vendor_curr);

    for ( $ii = 0; $ii < count( $data['options'] ); $ii++ ) {
        if($data['options'][$ii]['price_type'] == 'flat_fee'){
            $data['options'][$ii]['price'] = $data['options'][$ii]['price']/$rate;
        }
    }   
    return $data;
}
