
jQuery(document).ready(function () {

    jQuery.post(
        ajaxurl,
        {
            'action': 'scd_dokan_get_user_currency'
        },
        function (response) {
            // dokan-support-listing dokan-support-topic-wrapper
            var user_currency = response.split('<')[0].replace(' ','').toString()[0]+response.split('<')[0].replace(' ','').toString()[1]+response.split('<')[0].replace(' ','').toString()[2];
            var rate1 = scd_get_convert_rate(settings.baseCurrency, user_currency);
            var rate = scd_get_convert_rate(user_currency, settings.baseCurrency);
            jQuery("input[name='dokan_update_product']" ).click(function (){
                var elements =  jQuery('.wc-pao-addon-content-price .wc_input_price');
                for(var i=0 ; i< elements.length; i++){
                    var price = elements[i].value * rate;
                    elements[i].value = price;
                }
            });
             var elements =  jQuery('.wc-pao-addon-content-price .wc_input_price');
            for(var i=0 ; i< elements.length; i++){
                var price = elements[i].value * rate1;
                price = price.toFixed(jscd_options.decimalPrecision);
                price = scd_humanizeNumber(price);
                elements[i].value = price;
            }
        }
    );

//wc pao compatibibility
jQuery('.wc-pao-addon-checkbox,.wc-pao-addon-image-swatch,.wc-pao-addon-radio').click(function(){
      setTimeout(function (){
             scd_wc_pao_conversion();
           },200);
    });
    
//wc pao compatibibility
jQuery('.wc-pao-addon-select').change(function (){
setTimeout(function (){
scd_wc_pao_conversion();
},300);
});

jQuery('.wc-pao-addon-input-multiplier').focus(function (){
setTimeout(function (){
scd_wc_pao_conversion();
},300);
}).focusout(function (){
setTimeout(function (){
scd_wc_pao_conversion();
},300);
}).dblclick(function (){
setTimeout(function (){
scd_wc_pao_conversion();
},300);
});

//hide custom price input input-text wc-pao-addon-field wc-pao-addon-custom-price
if(jQuery('.wc-pao-addon-custom-price').length>0){
      jQuery('.wc-pao-addon-custom-price').attr('type','hidden');
      var new_inp='<input type="number" step="any" class="input-text scd-wc-pao-addon-custom-price" name="scd-wc-pao-customm-price"  data-price-type="flat_fee" value="" min="0" >';

      jQuery('.wc-pao-addon-custom-price').parent().append(new_inp);
        jQuery('.scd-wc-pao-addon-custom-price').focusout(function(){
            var price=jQuery(this).val();
           if(price!==''){
            var target_currency=scd_getTargetCurrency();
            //convert the value put by cutomer in target currency to basecurrency to pass it to wc pao
           price= scd_convert_value(price,target_currency,settings.baseCurrency);
            jQuery('.wc-pao-addon-custom-price').val(price);
             jQuery('.wc-pao-addon-custom-price').trigger('woocommerce-product-addons-update');;
           
             setTimeout(function (){
             scd_wc_pao_conversion();
           },300);
       
             }
        }).focusin(function (){
           setTimeout(function (){
             scd_wc_pao_conversion();
           },300);
        }).dblclick(function (){
           setTimeout(function (){
             scd_wc_pao_conversion();
           },300);
        });
}

    jQuery('.wc-pao-addon-custom-text,.wc-pao-addon-custom-textarea').keypress(function(){
      setTimeout(function (){
             scd_wc_pao_conversion();
           },200);
    }).focusout(function(){
      setTimeout(function (){
             scd_wc_pao_conversion();
           },200);
    });
    
});


jQuery(window).load(function () {


});