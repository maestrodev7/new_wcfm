<?php

/*===========================================================================
*                                                                           *
*                        AUCTION MAIL COMPATIBILITY                         *
*                                                                           *
*   Description: Send mail in the currency of the customer user             *
*                                                                           *
*==========================================================================*/


//***************************************************************************
//                  save the currency of the useer when he place a bid
//                  this will be use to send the mail
//              is assume that, uwa plugins can permit user to place a bid
//              unless he place a bigger valuer thant preview bid
add_action('ultimate_woocommerce_auction_place_bid','scd_ultimate_woocommerce_auction_place_bid',10,1);

function scd_ultimate_woocommerce_auction_place_bid($arrayVar){
    //save the target currency for the user which bid the product
    $product_id = $arrayVar['product_id'];
    $currency = get_post_meta($product_id, 'scd_auction_winning_currency',true);
    if (empty($currency)) {
        add_post_meta($product_id, 'scd_auction_winning_currency', scd_get_target_currency());
    }else{
        update_post_meta($product_id, 'scd_auction_winning_currency', scd_get_target_currency(),$currency);
    } 
}





















//**************************************************************************
//      Add the function which convert the price in the currency of user
// hooks which two parameters using st

//place bid mail is send by the session of the current user so target currency can be use
add_action('uwa_pro_outbid_bid_email','scd_woo_ua_auction_email_convert',9,2);
add_action('uwa_pro_bid_place_email','scd_woo_ua_auction_email_convert',9,2);

//the loser will receive mail in currency of the session who start sending the mail
add_action('woo_ua_auctions_loser_email_bidder','scd_woo_ua_auction_email_convert',9,2);
add_action('uwa_private_msg_email_admin','scd_woo_ua_auction_email_convert',9,2);


function scd_woo_ua_auction_email_convert($product_id, $winneruser){
    remove_action('wp','scd_init_use_without_increase_rate');
    if (!isset($_SESSION)) session_start();
        $_SESSION['scd_use_without_increase_rate'] = true;
    //if there is last add_filter

    remove_filter( 'wc_price', 'scd_convert_won_mail_price_in_html_second', 10);
    add_filter( 'wc_price', 'scd_convert_price_in_html_markup', 10,4);
}


































// hooks with one parameter send in currency of session start sending mail
add_action('uwa_pro_auction_relist_email','scd_woo_ua_auction_email_convert_1',9,1);
function scd_woo_ua_auction_email_convert_1($var){
    remove_action('wp','scd_init_use_without_increase_rate');
    if (!isset($_SESSION)) session_start();
        $_SESSION['scd_use_without_increase_rate'] = true;
    //if there is last add_filter

    add_filter( 'wc_price', 'scd_convert_won_mail_price_in_html_second', 10,4);   
}












































//send ending soon email in winner currency
add_action('woo_ua_auctions_ending_soon_email_bidders','scd_woo_ua_auction_ending_soon_email_convert',9,1);
function scd_woo_ua_auction_ending_soon_email_convert($product_id){
    //save the id of product for won mail in session
    remove_action('wp','scd_init_use_without_increase_rate');
    if (!isset($_SESSION)) session_start();
        $_SESSION['scd_use_without_increase_rate'] = true;
        $_SESSION['scd_auction_product_id'] = $product_id;
    //remove standart converter function for this case
    remove_filter( 'wc_price', 'scd_convert_price_in_html_markup', 10);

    //add the specific function to convert the winning bid. it is correspond to the first wc_price call function
    add_filter( 'wc_price', 'scd_convert_won_mail_price_in_html_second', 10,4);
}





























//send delete bid email in winner currency
add_action('uwa_pro_delete_bid_email','scd_uwa_pro_delete_bid_email',9,3);
function scd_uwa_pro_delete_bid_email($product_id, $userid, $deletedbid){
    remove_action('wp','scd_init_use_without_increase_rate');
    //save the id of product for won mail in session
    if (!isset($_SESSION)) session_start();
        $_SESSION['scd_use_without_increase_rate'] = true;
        $_SESSION['scd_auction_product_id'] = $product_id;

    //remove standart converter function for this case
    remove_filter( 'wc_price', 'scd_convert_price_in_html_markup', 10);
    
    //add the specific function to convert the winning bid. it is correspond to the first wc_price call function
    add_filter( 'wc_price', 'scd_convert_won_mail_price_in_html_second', 10,4);  

}






































//**********************************************************************************
//                              Winning bid mail
//                      Here we handle the won bid mail
//
add_action('woo_ua_auctions_won_email_bidder','scd_woo_ua_auction_won_email_convert',9,2);
add_action('uwa_email_remind_to_pay_notification','scd_woo_ua_auction_won_email_convert',9,2);
add_action('woo_ua_auctions_loser_email_bidder','scd_woo_ua_auction_email_convert',9,2);
//before won mail
function scd_woo_ua_auction_won_email_convert($product_id, $winneruser){
    remove_action('wp','scd_init_use_without_increase_rate');
        //save the id of product for won mail in session
    if (!isset($_SESSION)) session_start();
        $_SESSION['scd_use_without_increase_rate'] = true;
        $_SESSION['scd_auction_product_id'] = $product_id;

    //remove standart converter function for this case
    remove_filter( 'wc_price', 'scd_convert_price_in_html_markup', 10);
    add_filter( 'wc_price', 'scd_convert_won_mail_price_in_html_second', 10);

}












































































//*********************************************************************************
//          Function used to convert in won mail 
//          except winning bid
function scd_convert_won_mail_price_in_html_second($price_html, $price_formatted, $args, $unformatted_price){

    if (!isset($_SESSION)) session_start();
    $product_id = $_SESSION['scd_auction_product_id'] ;


    if(empty($args['currency']) || $args['currency'] == '' )

    {

        $currency = get_option( 'woocommerce_currency');

    }

    else

    {

        $currency = $args['currency'];

    }

    
    $target_currency = get_post_meta($product_id, 'scd_auction_winning_currency',true);


    if($target_currency != $currency)

    {           

        // We only enter here if the target currency differs from the currency in the args array

        $convert_rate = scd_get_conversion_rate($currency, $target_currency);

        if(!empty($convert_rate))

        {

            // The conversion rate is defined.  We will convert the price and call a function

            // to apply the proper formatting.

            $decimals = scd_options_get_decimal_precision();

            $converted_price = scd_function_convert_subtotal($unformatted_price, $currency, $target_currency, $decimals);

            $args['currency'] = $target_currency;

            $args['decimals'] = $decimals;

            $args['price_format'] = scd_change_currency_display_format ($args['price_format'], $target_currency);

            $price_html = scd_format_converted_price_to_html($converted_price, $args);

        }

    }
    return $price_html;
}
