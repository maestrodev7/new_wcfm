<?php

/*
  Plugin Name:SCD - Smart Currency Detector - For Woocommerce Auction Product 
  Plugin URI: https://gajelabs.com/customprofile
  Description: An addon who make the compatibility between SCD - Smart Currency Detector and  Ultimate Woocommmerce Product Auction Pro
  Author: gajelabs
  Author URI: https://gajelabs.com
  Version: 1.3
 */

//              <>


//include 'includes/scd-auction-mail.php';

if (in_array('scd-smart-currency-detector/index.php', apply_filters('active_plugins', get_option('active_plugins'))) && in_array('scd-smart-currency-detector-variant-for-wcfm/index.php', apply_filters('active_plugins', get_option('active_plugins'))) ){

add_filter( 'wcfm_product_manage_fields_auction_options', 'scd_wcfm_product_manage_fields_auction_options',999,3);//page of creation of auction

function scd_wcfm_product_manage_fields_auction_options($data, $product_id,$auction_product){
   
        # code...
        $vendor_curr= get_user_meta(get_current_user_id(), 'scd-user-currency',true);

        $data['woo_ua_opening_price']['label'] =  stristr($data['woo_ua_opening_price']['label'],'(',true).'('. get_woocommerce_currency_symbol( get_user_meta(get_current_user_id(), 'scd-user-currency',true)).')';
        $data['woo_ua_opening_price']['value'] = scd_convert_auction_product($data['woo_ua_opening_price']['value'],$product_id,true);


        $data['woo_ua_lowest_price']['label'] =  stristr($data['woo_ua_lowest_price']['label'],'(',true).'('.get_woocommerce_currency_symbol( get_user_meta(get_current_user_id(), 'scd-user-currency',true)).')';
         $data['woo_ua_lowest_price']['value'] = scd_convert_auction_product($data['woo_ua_lowest_price']['value'],$product_id,true);

        $data['_regular_price']['label'] =  stristr($data['_regular_price']['label'],'(',true).'('. get_woocommerce_currency_symbol( get_user_meta(get_current_user_id(), 'scd-user-currency',true)).')';
         $data['_regular_price']['value'] = scd_convert_auction_product($data['_regular_price']['value'],$product_id,true);

        $data['woo_ua_bid_increment']['label'] =  stristr($data['woo_ua_bid_increment']['label'],'(',true).'('. get_woocommerce_currency_symbol( get_user_meta(get_current_user_id(), 'scd-user-currency',true)).')';
        $data['woo_ua_bid_increment']['value'] = $data['woo_ua_bid_increment']['value'];

        /* Variable Increment */
        $scd_uwa_var_bid = get_post_meta($product_id, 'uwa_auction_variable_bid_increment',true);
        if(!empty($scd_uwa_var_bid) && $scd_uwa_var_bid == "yes" ){
            ?>
            <script>
                interval_scd_uwa = setInterval(function(){
                    product_id = <?php echo $product_id;?>;
                    
                    scd_uwa_prices = jQuery('.uwa_auction_price_fields');
                    if(scd_uwa_prices.length>0){
                    
                        clearInterval(interval_scd_uwa);
                        rate =  <?php echo scd_rate_auction_product($product_id); ?>;
                        for(i=0;i<scd_uwa_prices.length;i++){
                            if(scd_uwa_prices.eq(i).attr('type') == "number"){
                                value = scd_uwa_prices.eq(i).val()*rate;
                                scd_uwa_prices.eq(i).val(value.toFixed(1) );
                            }
                        }
                    }
                    
                },500);
                    </script>
        <?php
        }
    return  $data;
}


function scd_rate_auction_product($product_id){
               
    $product_base_currency =  get_woocommerce_currency();
    $wc_currency = $product_base_currency;

    $regs = get_post_meta($product_id, 'scd_other_options',TRUE);

    if (!empty($regs)) {
        //$currencyPrice = $regs["currencyPrice"];
        $product_base_currency = $regs["currencyVal"];
    }

    if ($wc_currency == $product_base_currency) {
        return  1;
    }

    return  floatval(scd_get_conversion_rate($wc_currency,$product_base_currency));

}


add_action( 'after_wcfm_products_manage_meta_save','scd_uwa_vendor_support_products_manage_meta_save', 999, 2);//recuperqtion des valeurs  entrees

function scd_uwa_vendor_support_products_manage_meta_save($new_product_id, $wcfm_products_manage_form_data ){


    global $wpdb, $WCFM, $_POST;

    

    if( $wcfm_products_manage_form_data['product_type'] == 'auction' ) {

        

        $_regular_price = scd_convert_auction_product($wcfm_products_manage_form_data['_regular_price'],$new_product_id,false);

        $woo_ua_opening_price = scd_convert_auction_product($wcfm_products_manage_form_data['woo_ua_opening_price'],$new_product_id,false);

        $woo_ua_lowest_price = scd_convert_auction_product($wcfm_products_manage_form_data['woo_ua_lowest_price'],$new_product_id,false);

        $woo_ua_bid_increment = scd_convert_auction_product($wcfm_products_manage_form_data['woo_ua_bid_increment'],$new_product_id,false);        


        /* Save data to database */

        $post_id = $new_product_id;


        if (isset($_regular_price)) {

            update_post_meta($post_id, '_regular_price', wc_format_decimal(wc_clean($_regular_price)));

            update_post_meta($post_id, '_price', wc_format_decimal(wc_clean($_regular_price)));

        }      

        if (isset($woo_ua_opening_price)) {         

            update_post_meta( $post_id, 'woo_ua_opening_price', wc_format_decimal(wc_clean($woo_ua_opening_price)) );

        }

        if( isset( $woo_ua_lowest_price ) )  {              

            update_post_meta( $post_id, 'woo_ua_lowest_price', wc_format_decimal(wc_clean($woo_ua_lowest_price)) );

        }
        

        if( isset( $woo_ua_bid_increment)  ) {          

            update_post_meta( $post_id, 'woo_ua_bid_increment', wc_format_decimal(wc_clean( $woo_ua_bid_increment )) );

            delete_post_meta( $post_id, 'uwa_auction_variable_bid_increment' );     

            delete_post_meta( $post_id, 'uwa_var_inc_price_val' );

        }
    

         /* Variable Increment */

        if (isset($wcfm_products_manage_form_data['uwa_auction_variable_bid_increment']) && isset($wcfm_products_manage_form_data['uwa_var_inc_val'])){

            if($wcfm_products_manage_form_data['uwa_auction_variable_bid_increment']=="on" && !empty($wcfm_products_manage_form_data['uwa_var_inc_val']) && empty($wcfm_products_manage_form_data['woo_ua_bid_increment'])){

        
                update_post_meta($post_id, 'uwa_auction_variable_bid_increment', "yes");
               
                foreach($wcfm_products_manage_form_data['uwa_var_inc_val'] as $key => $inc_var_value){
                    foreach($inc_var_value as $key2=> $champs){
                        if ( gettype($champs != string ) ){
                            $wcfm_products_manage_form_data['uwa_var_inc_val'][$key][$key2] = scd_convert_auction_product($champs,$new_product_id,false);
                        }
                    }
                }
                update_post_meta($post_id, 'uwa_var_inc_price_val',$wcfm_products_manage_form_data['uwa_var_inc_val'] );

                delete_post_meta( $post_id, 'woo_ua_bid_increment' );
            }

        }

    } /* end of if */

} /* end of function  */


function scd_convert_auction_product($price,$product_id,$reverse=true){
      //get the currency of the vendor when is create the produc

    $product_base_currency = get_woocommerce_currency();
    if (get_post_meta($product_id, 'scd_other_options')) {
        $regs = get_post_meta($product_id, 'scd_other_options', TRUE);
        //$currencyPrice = $regs["currencyPrice"];
        $product_base_currency = $regs["currencyVal"];
    }

    $wc_currency = get_woocommerce_currency();

    if ($wc_currency == $product_base_currency) {
        return  floatval($price);
    }


    if ($reverse) {// from wc currency to product current
        # code...
        $rate =  floatval(scd_get_conversion_rate($wc_currency,$product_base_currency));
        
    }else{ // from product currency to wc currency
        $rate = floatval( scd_get_conversion_rate($product_base_currency,$wc_currency));
    }

    $myprice = $rate*floatval($price);

    $decimals = scd_options_get_decimal_precision();

  
        
    if ($decimals == 0)
        $myprice = ceil($myprice);
    else {
        $myprice = round($myprice, $decimals);
    }

    if ($product_base_currency == 'JPY' && $reverse) {
        $myprice = round($myprice, 0);
    }
    if ($wc_currency == 'JPY' && !$reverse) {
        $myprice = round($myprice, 0);
    }

    return $myprice;
}


//    return apply_filters('wc_aelia_cs_product_base_currency', $default_currency, $product_id);
add_filter('wc_aelia_cs_product_base_currency','scd_wc_aelia_cs_product_base_currency',999,2);
function scd_wc_aelia_cs_product_base_currency($default_currency,$product_id){

    if (get_post_meta($product_id, 'scd_other_options')) {
        $regs = get_post_meta($product_id, 'scd_other_options', TRUE);
        //$currencyPrice = $regs["currencyPrice"];
        $default_currency = $regs["currencyVal"];
    }
    return $default_currency;
}

 add_action('ultimate_woocommerce_auction_after_bid_form','scd_ultimate_woocommerce_auction_after_bid_form');

 function scd_ultimate_woocommerce_auction_after_bid_form(){
     
    ?>
    
    <script type="text/javascript">
        uwa_currencys = document.getElementsByClassName('uwa_currency');
        symbl_curr = '<?php echo get_woocommerce_currency_symbol(scd_get_target_currency()) ;?>';
        for (var i = 0; i < uwa_currencys.length; i++) {
            uwa_currencys[i].innerHTML = symbl_curr;
        }

      
        rate = <?php echo scd_get_conversion_rate(get_woocommerce_currency(), scd_get_target_currency());?>
        

        minval = rate*parseFloat(jQuery('#uwa_bid_value').attr('min'));
        jQuery('#uwa_bid_value').attr('min',minval.toFixed(2));

        minval = rate*parseFloat(jQuery('#uwa_bid_value_direct').attr('min'));
        jQuery('#uwa_bid_value_direct').attr('min',minval.toFixed(2));
        jQuery('#uwa_bid_value_direct').val(minval.toFixed(2));
    </script>
    <?php
 }

 add_action('woocommerce_auction_add_to_cart','scd_woocommerce_auction_add_to_cart',24);
 add_action('woocommerce_single_product_summary','scd_woocommerce_auction_add_to_cart',24);
 function scd_woocommerce_auction_add_to_cart(){
    if(!isset($_SESSION))  {  session_start(); }
        $_SESSION['scd_overwrite_woocommerce_currency'] = true;

}

add_filter('woocommerce_currency', 'scd_overwrite_woocommerce_currency', 999, 1);
function scd_overwrite_woocommerce_currency($currency){
//overwrite get_woocommerce_current to display alert of auction product
    if (isset($_SESSION['scd_overwrite_woocommerce_currency']) && $_SESSION['scd_overwrite_woocommerce_currency']) {
          # code...
        unset($_SESSION['scd_overwrite_woocommerce_currency']);
        return scd_get_target_currency();
    } 
    return $currency;

}


add_filter('woocommerce_get_price_html','scd_get_auction_price_html',10,2);

//*Over write Woocommerce get_price_html for Auction Product  
function scd_get_auction_price_html( $price,$product) {

    if ($_POST['controller'] == "wcfm-products") {
        $user_curr = get_user_meta(get_current_user_id(), 'scd-user-currency',true) ;
        $rate = scd_get_conversion_rate(get_woocommerce_currency(),$user_curr);
        

        $arg = array('currency' => $user_curr);

        $id = $product->id;
        $auction_selling_type = get_post_meta( $id, 'woo_ua_auction_selling_type', true );

        if($product->get_type() == "auction" && ($auction_selling_type == "auction" || $auction_selling_type == "both" ||     $auction_selling_type == "")){
            $product = new WC_Product_Auction($product); 
            if ($product->is_uwa_expired() && $product->is_uwa_live() ){
                
                if ($product->get_uwa_auction_expired() == '3'){
                    
                    $price = __('<span class="woo-ua-sold-for sold_for">Sold for</span>: ','woo_ua').wc_price($rate*$product->get_price(),$arg);
                }
                else{
                    
                    if ($product->get_uwa_auction_current_bid()){

                        if ( $product->is_uwa_reserve_met() == FALSE){
                            
                            $price = __('<span class="woo-ua-winned-for reserve_not_met">Reserve price Not met!</span> ','woo_ua');
                            
                        } else{
                            $price = __('<span class="woo-ua-winned-for winning_bid">Winning Bid</span>: ','woo_ua').wc_price($rate*$product->get_uwa_auction_current_bid(), $arg);
                        }
                    }
                    else{
                        $price = __('<span class="woo-ua-winned-for expired">Auction Expired</span> ','woo_ua');
                    }


                } /* end of else */

            } elseif(!$product->is_uwa_live()){
                
                $price = '<span class="woo-ua-auction-price starting-bid" data-auction-id="'.$id.'" data-bid="'.$product->get_uwa_auction_current_bid().'" data-status="">'.__('<span class="woo-ua-starting auction">Starting bid</span>: ','woo_ua').wc_price($rate*$product->get_uwa_current_bid(), $arg).'</span>';
                
            } else {
                
                if($product->get_uwa_auction_silent() == 'yes'){
                    $price = '<span class="woo-ua-auction-price" data-auction-id="'.$id.'"  data-status="running">'.__('<span class="current auction">This auction is silent bid.</span> ','woo_ua').'</span>';
                } else{
                
                    if (!$product->get_uwa_auction_current_bid()){
                        $price = '<span class="woo-ua-auction-price starting-bid" data-auction-id="'.$id.'" data-bid="'.$product->get_uwa_auction_current_bid().'" data-status="running">'.__('<span class="woo-ua-current auction">Starting bid</span>: ','woo_ua').wc_price($rate*$product->get_uwa_current_bid(), $arg).'</span>';
                    } else {
                        $price = '<span class="woo-ua-auction-price current-bid" data-auction-id="'.$id.'" data-bid="'.$product->get_uwa_auction_current_bid().'" data-status="running">'.__('<span class="woo-ua-current auction">Current bid</span>: ','woo_ua').wc_price($rate*$product->get_uwa_current_bid(), $arg).'</span>';
                    }
                }

            }
        } 
    }
    
    return  $price;
}


add_action('init','scd_ajust_bit_value_auction_product',1);
function scd_ajust_bit_value_auction_product(){
    $bid = abs(round(str_replace(',', '.', $_REQUEST['uwa_bid_value']), wc_get_price_decimals()));  
    if (!isset($_SESSION)) session_start();
        $_SESSION['scd_use_without_increase_rate'] = true;
    $rate = scd_get_conversion_rate(get_woocommerce_currency(), scd_get_target_currency());
    $_REQUEST['uwa_bid_value'] = $bid/$rate;     

} 
 /*si cette partie est decommenté; il faut impérativement mettre en commentaire la partie allant de "jQuery('button#placebidbutton').on('click', function(){" (de la ligne 199 )à "});"(de la ligne 210)*/


add_action("wp_ajax_expired_auction", "scd_uwa_ajax_auction_expired_callback",9);

add_action("uwa_ajax_expired_auction", "scd_uwa_ajax_auction_expired_callback",9);

function scd_uwa_ajax_auction_expired_callback() {

		

    if (isset($_POST["post_id"])) {			 

        

            $product_data = wc_get_product( wc_clean( $_POST["post_id"] ) );



                //$product_base_currency = $product_data->uwa_aelia_get_base_currency();  
                $user_curr = scd_get_target_currency();

                  //$args = array("currency" => $product_base_currency);   
                  $args = array("currency" => $user_curr);
                  
                  $rate = scd_get_conversion_rate(get_woocommerce_currency(),$user_curr);



            if ($product_data->is_uwa_expired()) {



                if (isset($_POST["ret"]) && $_POST["ret"] != '0') {

                    

                    if ($product_data->is_uwa_reserved()) {

                        if (!$product_data->is_uwa_reserve_met()) {

                            

                            echo "<p class='woo_ua_auction_product_reserve_not_met'>";

                            _e("Reserve price has not been met!", 'woo_ua');

                            echo "</p>";							

                            die();

                        }

                    }

                    

                    $current_bidder = $product_data->get_uwa_auction_current_bider();

                    

                    if ($current_bidder) {

                        

                        printf(__("Winning bid is %s. by %s.", 'woo_ua'), wc_price($product_data->round(get_uwa_current_bid()*$rate,1),  $args), uwa_user_display_name($current_bidder));

                        echo "</p>";

                        if ( get_current_user_id() == $current_bidder ){

                            

                        //WC()->cart->add_to_cart( $_POST["post_id"], 1 ) ;	

                            

                        $checkout_url = esc_attr(add_query_arg("pay-uwa-auction",$product_data->get_id(), uwa_auction_get_checkout_url()));

                        

                        $get_charged_for_winner = get_option("_uwa_w_s_charge_".$product_data->get_id()."_".$current_bidder, false);

                        $w_product_price = $product_data->get_uwa_auction_current_bid();

                        

                            if($get_charged_for_winner == $w_product_price){

                                

                                echo '<p><a href="'.$checkout_url.'" class="button">'.apply_filters('ultimate_woocommerce_auction_pay_now_button_text', __( 'Get Item', 'woo_ua' ), $product_data).'</a></p>';

                                

                            } else {

                                

                                echo '<p><a href="'.$checkout_url.'" class="button">'.apply_filters('ultimate_woocommerce_auction_pay_now_button_text', __( 'Pay Now', 'woo_ua' ), $product_data).'</a></p>';

                            }

                        }

                        

                    } else {

                        echo "<p>";

                        _e("There were no bids for this auction.", 'woo_ua');

                        echo "</p>";

                        die();

                    }



                }



            } else {



                echo "<div>";

                

                printf(__("Please refresh page.", 'woo_ua'));



                echo "</div>";

            }

    }

    die();

}


add_action( 'woocommerce_account_uwa-auctions_endpoint', 'scd_uwa_auctions_endpoint_content',9 );

function scd_uwa_auctions_endpoint_content(){
    if (!isset($_SESSION)) session_start();
        $_SESSION['scd_use_without_increase_rate'] = true;
}	

add_filter('widget_title', 'scd_auction_widget',1,3);
function scd_auction_widget($title,$instance,$id_base){
    if (array_key_exists('uwa_hide_time',$instance)) {//alors le widget a pour un action product
        if (!isset($_SESSION)) session_start();
        $_SESSION['scd_use_without_increase_rate'] = true;
    }
}


}

