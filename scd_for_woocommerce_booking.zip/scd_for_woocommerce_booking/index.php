<?php
/*
  Plugin Name:SCD - Smart Currency Detector - For woocommerce_bookings addon

  Plugin URI: https://gajelabs.com/customprofile

  Description: Get compatibility with your woocommerce bookins.

  Author: gajelabs

  Author URI: https://gajelabs.com

  Version: 1.1

*/

if (in_array('scd-smart-currency-detector/index.php', apply_filters('active_plugins', get_option('active_plugins'))) || in_array('scd_dokan_marketplace/index.php', apply_filters('active_plugins', get_option('active_plugins'))) ||
in_array('scd-smart-currency-detector-variant-for-wcfm/index.php', apply_filters('active_plugins', get_option('active_plugins'))) ||
in_array('scd_wcfm_marketplace/index.php', apply_filters('active_plugins', get_option('active_plugins')))){

    // SCD for WC Booking
    add_action('woocommerce_bookings_calculated_booking_cost_success_output','scd_booking',10,3);
    // SCD for dokan booking compatibility
	add_action('dokan_new_product_added', 'scd_dokan_booking', 12, 1);
	add_action('dokan_product_updated', 'scd_dokan_booking', 12, 1);
	add_action('woocommerce_bookings_after_booking_base_cost', 'scd_dokan_booking_base_cost',10,1);
	add_action('woocommerce_bookings_after_booking_block_cost', 'scd_dokan_booking_block_cost',10,1);
	add_action('woocommerce_bookings_after_display_cost', 'scd_dokan_booking_display_cost',10,1);
    // SCD for WCFM Booking compatibility
    add_action( 'after_wcfm_products_manage_meta_save', 'scd_wcfm_booking_save', 21, 2 );
    add_filter( 'wcfm_wcbokings_cost_fields','scd_wcfm_booking_cost_fields', 10, 2);

}

/******************************************************************
  scd woocommerce booking compatibility 
********************************************************************/
function scd_booking($output, $display_price, $product){
    if(empty($args['currency']) || $args['currency'] = '' )
    {
        $currency = get_option( 'woocommerce_currency');
    }
    else
    {
        $currency = $args['currency'];
    }
    $target_currency = scd_get_target_currency();
    if($target_currency != $currency)
    {           
        // We only enter here if the target currency differs from the currency in the args array
        $convert_rate = scd_get_conversion_rate($currency, $target_currency);
        if(!empty($convert_rate))
        {
            // The conversion rate is defined.  We will convert the price and call a function
            // to apply the proper formatting.
            $decimals = scd_options_get_decimal_precision();
            $converted_price = scd_function_convert_subtotal($display_price, $currency, $target_currency, $decimals);
            $args['currency'] = $target_currency;
            $args['decimals'] = $decimals;
            $args['price_format'] = get_woocommerce_price_format();
            $args['price_format'] = scd_change_currency_display_format ($args['price_format'], $target_currency);
            $price_html = scd_format_converted_price_to_html($converted_price, $args);
        }
    }
    else{
        $decimals = scd_options_get_decimal_precision();
        $converted_price = scd_function_convert_subtotal($display_price, $currency, $target_currency, $decimals);
        $args['currency'] = $target_currency;
        $args['decimals'] = $decimals;
        $args['price_format'] = get_woocommerce_price_format();
        $args['price_format'] = scd_change_currency_display_format ($args['price_format'], $target_currency);
        $price_html = scd_format_converted_price_to_html($converted_price, $args);
    }
    //return scd_change_currency_display_format ($args['price_format'], $target_currency);
    $output = apply_filters( 'woocommerce_bookings_booking_cost_string', __( 'Booking cost', 'woocommerce-bookings' ), $product ) . ': <strong>' . $price_html  . '</strong>';
    return $output;
}

/******************************************************************
  scd dokan booking compatibility
********************************************************************/
function scd_dokan_booking($post_id) {
    update_post_meta($post_id, '_scd_wc_booking_cost', $_POST['_wc_booking_cost']);
    update_post_meta($post_id, '_scd_wc_booking_block_cost', $_POST['_wc_booking_block_cost']);
    update_post_meta($post_id, '_scd_wc_display_cost', $_POST['_wc_display_cost']);
    $base_currency = get_option('woocommerce_currency');
    $_POST['_wc_booking_cost'] = scd_function_convert_subtotal($_POST['_wc_booking_cost'] , scd_get_user_currency(), $base_currency , 1);
    $_POST['_wc_booking_block_cost'] = scd_function_convert_subtotal($_POST['_wc_booking_block_cost'] , scd_get_user_currency(), $base_currency, 1);
    $_POST['_wc_display_cost'] = scd_function_convert_subtotal($_POST['_wc_display_cost'] , scd_get_user_currency(), $base_currency, 1);
    $product = new WC_Product_Booking( $post_id );
    $posted_props = array(
        'block_cost'                 => wc_clean( $_POST['_wc_booking_block_cost'] ),
        'cost'                       => wc_clean( $_POST['_wc_booking_cost'] ),
        'display_cost'               => wc_clean( $_POST['_wc_display_cost'] ),
    );
    $product->set_props( $posted_props );
    $product->save();
}

function scd_dokan_booking_base_cost($post_id){
    ?>
<script>
jQuery(document).ready(function() {
    jQuery('#_wc_booking_cost').val(<?php echo get_post_meta($post_id,'_scd_wc_booking_cost',true); ?>);
});
</script>
<?php
}
function scd_dokan_booking_block_cost($post_id){
?>
<script>
jQuery(document).ready(function() {
    jQuery('#_wc_booking_block_cost').val(
        <?php echo get_post_meta($post_id, '_scd_wc_booking_block_cost', true); ?>);
});
</script>
<?php
}
function scd_dokan_booking_display_cost($post_id){
?>
<script>
jQuery(document).ready(function() {
    jQuery('#_wc_display_cost').val(<?php echo get_post_meta($post_id, '_scd_wc_display_cost', true); ?>);
});
</script>
<?php
}

/******************************************************************
  scd for wcfm booking compatibility  
********************************************************************/
function scd_wcfm_booking_save($new_product_id, $wcfm_products_manage_form_data){

    if( $wcfm_products_manage_form_data['product_type'] == 'booking' ) 
    {
        update_post_meta($new_product_id, '_scd_wc_booking_cost', $wcfm_products_manage_form_data['_wc_booking_cost']);
        update_post_meta($new_product_id, '_scd_wc_booking_block_cost', $wcfm_products_manage_form_data['_wc_booking_block_cost']);
        update_post_meta($new_product_id, '_scd_wc_display_cost', $wcfm_products_manage_form_data['_wc_display_cost']);
        $user_curr = get_user_meta(get_current_user_id(), 'scd-user-currency',true);
        $base_currency = get_option('woocommerce_currency');
        $rate = scd_get_conversion_rate($user_curr,$base_currency);

        $wcfm_products_manage_form_data['_wc_booking_cost'] = $rate*$wcfm_products_manage_form_data['_wc_booking_cost'];
        $wcfm_products_manage_form_data['_wc_booking_block_cost'] = $rate*$wcfm_products_manage_form_data['_wc_booking_block_cost'];
        $wcfm_products_manage_form_data['_wc_display_cost'] = $rate*$wcfm_products_manage_form_data['_wc_display_cost'];
        
        $classname    = WC_Product_Factory::get_product_classname( $new_product_id, 'booking' );
        $product      = new $classname( $new_product_id );
        $errors = $product->set_props( apply_filters( 'wcfm_booking_data_factory', array(
        'block_cost'                  => wc_clean( $wcfm_products_manage_form_data['_wc_booking_block_cost'] ),
            'cost'                       => wc_clean( $wcfm_products_manage_form_data['_wc_booking_cost'] ),
            'display_cost'               => wc_clean( $wcfm_products_manage_form_data['_wc_display_cost'] ),
        ), $new_product_id, $product, $wcfm_products_manage_form_data ) );
        if ( is_wp_error( $errors ) ) {
            //echo '{"status": false, "message": "' . $errors->get_error_message() . '", "id": "' . $new_product_id . '", "redirect": "' . get_permalink( $new_product_id ) . '"}';
        }
        $product->save();
    }

}

function scd_wcfm_booking_cost_fields($cost_fields, $product_id){
	if( $product_id ) {
        $target_currency = get_user_meta(get_current_user_id(), 'scd-user-currency',true);
        $base_currency = get_option('woocommerce_currency');
        $bookable_product = new WC_Product_Booking( $product_id );
        
		$booking_cost = $bookable_product->get_cost( 'edit' );
		$booking_base_cost = $bookable_product->get_block_cost( 'edit' );
		$display_cost = $bookable_product->get_display_cost( 'edit' );
	}
    $base_currency = get_option('woocommerce_currency');
    $target_currency = get_user_meta(get_current_user_id(), 'scd-user-currency',true);

    $cost_fields['_wc_booking_cost']['label'] = $cost_fields['_wc_booking_cost']['label'] . '(' . get_woocommerce_currency_symbol($target_currency)  . ')';
	$cost_fields['_wc_booking_cost']['value'] = get_post_meta($product_id, '_scd_wc_booking_cost', true);
    
    $cost_fields['_wc_booking_block_cost']['label'] = $cost_fields['_wc_booking_block_cost']['label'] . '(' . get_woocommerce_currency_symbol($target_currency) . ')';
	$cost_fields['_wc_booking_block_cost']['value'] = get_post_meta($product_id, '_scd_wc_booking_block_cost', true);
    
    $cost_fields['_wc_display_cost']['label'] = $cost_fields['_wc_display_cost']['label'] . '(' . get_woocommerce_currency_symbol($target_currency) . ')';
	$cost_fields['_wc_display_cost']['value'] = get_post_meta($product_id, '_scd_wc_display_cost', true);

    return $cost_fields;

}

/******************************************************************
  Over write Woocommerce get_price_html for Booking Product
********************************************************************/
add_filter('woocommerce_get_price_html','scd_get_booking_price_html',10,2);
function scd_get_booking_price_html( $price,$product) {
    if ($_POST['controller'] == "wcfm-products" && $product->get_type() == "booking") {
        $user_curr = get_user_meta(get_current_user_id(), 'scd-user-currency',true) ;
        $rate = scd_get_conversion_rate(get_woocommerce_currency(),$user_curr);
        $args = array("currency"=> $user_curr);
        
            $base_price = WC_Bookings_Cost_Calculation::calculated_base_cost( $product );

            if ( 'incl' === get_option( 'woocommerce_tax_display_shop' ) ) {
                if ( function_exists( 'wc_get_price_excluding_tax' ) ) {
                    $display_price = wc_get_price_including_tax( $product, array(
                        'qty' => 1,
                        'price' => $base_price,
                    ) );
                } else {
                    $display_price = $product->get_price_including_tax( 1, $base_price );
                }
            } else {
                if ( function_exists( 'wc_get_price_excluding_tax' ) ) {
                    $display_price = wc_get_price_excluding_tax( $product, array(
                        'qty' => 1,
                        'price' => $base_price,
                    ) );
                } else {
                    $display_price = $product->get_price_excluding_tax( 1, $base_price );
                }
            }
            $display_price = $display_price*$rate;
            $display_price_suffix  = wc_price($display_price, $args) . $product->get_price_suffix();
            $original_price_suffix = wc_price($display_price, $args)  . $product->get_price_suffix();

            if ( $original_price_suffix !== $display_price_suffix ) {
                $price_html = "<del>{$original_price_suffix}</del><ins>{$display_price_suffix}</ins>";
            } elseif ( $display_price ) {
                if ( $product->has_additional_costs() || $product->get_display_cost() ) {
                    /* translators: 1: display price */
                    $price_html = sprintf( __( 'From: %s', 'woocommerce-bookings' ), wc_price($display_price, $args)  ) . $product->get_price_suffix();
                } else {
                    $price_html = wc_price($display_price, $args)  . $product->get_price_suffix();
                }
            } elseif ( ! $product->has_additional_costs() ) {
                $price_html = __( 'Free', 'woocommerce-bookings' );
            } else {
                $price_html = '';
            }
    	return $price_html;
	}elseif ($_POST['controller'] == "wcfm-products" && $product->get_type() !== "booking") {
		$price_html = $price;
		return $price_html;
	}
	elseif ($_POST['controller'] !== "wcfm-products") {
		$price_html = $price;
		return $price_html;
	}
}