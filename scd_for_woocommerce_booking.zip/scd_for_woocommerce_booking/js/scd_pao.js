
jQuery(document).ready(function () {

//wc pao compatibibility
jQuery('.wc-pao-addon-checkbox,.wc-pao-addon-image-swatch,.wc-pao-addon-radio').click(function(){
      setTimeout(function (){
             scd_wc_pao_conversion();
           },200);
    });
    
//wc pao compatibibility
jQuery('.wc-pao-addon-select').change(function (){
setTimeout(function (){
scd_wc_pao_conversion();
},300);
});

jQuery('.wc-pao-addon-input-multiplier').focus(function (){
setTimeout(function (){
scd_wc_pao_conversion();
},300);
}).focusout(function (){
setTimeout(function (){
scd_wc_pao_conversion();
},300);
}).dblclick(function (){
setTimeout(function (){
scd_wc_pao_conversion();
},300);
});

//hide custom price input input-text wc-pao-addon-field wc-pao-addon-custom-price
if(jQuery('.wc-pao-addon-custom-price').length>0){
      jQuery('.wc-pao-addon-custom-price').attr('type','hidden');
      var new_inp='<input type="number" step="any" class="input-text scd-wc-pao-addon-custom-price" name="scd-wc-pao-customm-price"  data-price-type="flat_fee" value="" min="0" >';

      jQuery('.wc-pao-addon-custom-price').parent().append(new_inp);
        jQuery('.scd-wc-pao-addon-custom-price').focusout(function(){
            var price=jQuery(this).val();
           if(price!==''){
            var target_currency=scd_getTargetCurrency();
            //convert the value put by cutomer in target currency to basecurrency to pass it to wc pao
           price= scd_convert_value(price,target_currency,settings.baseCurrency);
            jQuery('.wc-pao-addon-custom-price').val(price);
             jQuery('.wc-pao-addon-custom-price').trigger('woocommerce-product-addons-update');;
           
             setTimeout(function (){
             scd_wc_pao_conversion();
           },300);
       
             }
        }).focusin(function (){
           setTimeout(function (){
             scd_wc_pao_conversion();
           },300);
        }).dblclick(function (){
           setTimeout(function (){
             scd_wc_pao_conversion();
           },300);
        });
}

    jQuery('.wc-pao-addon-custom-text,.wc-pao-addon-custom-textarea').keypress(function(){
      setTimeout(function (){
             scd_wc_pao_conversion();
           },200);
    }).focusout(function(){
      setTimeout(function (){
             scd_wc_pao_conversion();
           },200);
    });
    
});


jQuery(window).load(function () {


});