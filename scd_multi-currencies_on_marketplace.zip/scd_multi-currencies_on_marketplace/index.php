<?php

/*
  Plugin Name: SCD - Smart Currency Detector - Premium Varaiant for marketplace - price in vendor currency
  Plugin URI: https://gajelabs.com/customprofile
  Description: Display price in vendor currency 
  Author: gajelabs
  Author URI: https://gajelabs.com
  Version: 2.2
 */


add_filter('scd_enable_price_in_vendor_currency','scd_customprice_enabled',10);
function scd_customprice_enabled($enable_conversion) {
    return false;
}

function scd_pvc_require() {
    echo '<h4 style="color:red;">SCD Price in vendor currency require SCD premium variant for WCFM. <a target="__blank" href="https:gajelabs.com">You can get it here</a></h4>';
}

if (in_array('scd-smart-currency-detector/index.php', apply_filters('active_plugins', get_option('active_plugins')))  && in_array('scd-smart-currency-detector-variant-for-wcfm/index.php', apply_filters('active_plugins', get_option('active_plugins'))) ){

include 'scd_vendor_currency.php';

}
