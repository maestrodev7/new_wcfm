<?php

/**
 * display price in foreign currency format.
 *
 * @since 0.1.0
 */
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('ch_scd_pvc_js', trailingslashit(plugins_url('', __FILE__)).'js/scd_pvc.js', [], '5.5.3', true);
});

add_action('wp', 'tests');

//add_filter('scd_enable_js_conversion', 'scd_pvc_enable_js_conversion', 11, 1);

function scd_pvc_enable_js_conversion($enableJsConversions)
{
    return false;
}

function tests()
{
    if (is_shop() || is_product() || is_cart() || is_checkout()) {
        add_filter('woocommerce_product_get_regular_price', 'scd_pvc_overwrite_wc_product_get_regular_price', 99, 2);
        add_filter('woocommerce_product_get_sale_price', 'scd_pvc_overwrite_wc_product_get_sale_price', 99, 2);
        add_filter('woocommerce_product_get_price', 'scd_pvc_overwrite_wc_product_get_price', 99, 2);

        // Variable
        //add_filter('woocommerce_product_variation_get_regular_price', 'custom_price', 99, 2 );
        add_filter('woocommerce_product_variation_get_price', 'custom_price', 99, 2);

        // Variations (of a variable product)
        //les 3 ci
        add_filter('woocommerce_variation_prices_price', 'custom_variation_price', 99, 3);
        add_filter('woocommerce_variation_prices_regular_price', 'custom_variation_price', 99, 3);
        add_filter('woocommerce_variation_prices_sale_price', 'custom_variation_price', 99, 3);
    }
}

if (!function_exists('array_key_last')) {
    function array_key_last(array $array)
    {
        if (!empty($array)) {
            return key(array_slice($array, -1, 1, true));
        }
    }
}

if (!function_exists('array_key_first')) {
    function array_key_first(array $arr)
    {
        foreach ($arr as $key => $unused) {
            return $key;
        }
    }
}

function custom_price($price, $product)
{
    // Delete product cached price  (if needed)
    wc_delete_product_transients($product->get_id());
    list($regprice, $saleprice, $currency) = scd_get_product_price($product, $product->get_variation_id());

    if (empty($saleprice)) {
        $saleprice = $regprice;
    }
    if ($currency == get_option('woocommerce_currency', true)) {
        $saleprice = $price;
    }

    return $saleprice;
}

function custom_variation_price($price, $variation, $product)
{
    // Delete product cached price  (if needed)
    wc_delete_product_transients($variation->get_id());
    list($regprice, $saleprice, $currency) = scd_get_product_price($product, $variation->get_id());

    if (empty($saleprice)) {
        $saleprice = $regprice;
    }

    if ($currency == get_option('woocommerce_currency', true)) {
        $saleprice = $price;
    }

    return $saleprice;
}

/**
 * Overwrite the Woocommerce regular price of a product.
 */
function scd_pvc_overwrite_wc_product_get_regular_price($price, $product)
{
    list($regprice, $saleprice, $currency) = scd_get_product_price($product);
    if ($currency == get_option('woocommerce_currency', true)) {
        $regprice = $price;
    }

    return $regprice;
}

/**
 * Overwrite the Woocommerce sale price of a product.
 */
function scd_pvc_overwrite_wc_product_get_sale_price($price, $product)
{
    list($regprice, $saleprice, $currency) = scd_get_product_price($product);
    if ($currency == get_option('woocommerce_currency', true)) {
        $saleprice = $price;
    }

    return $saleprice;
}

/**
 * Overwrite the Woocommerce price of a product.
 */
function scd_pvc_overwrite_wc_product_get_price($price, $product)
{
    list($regprice, $saleprice, $currency) = scd_get_product_price($product);

    if (empty($saleprice)) {
        $saleprice = $regprice;
    }
    if ($currency == get_option('woocommerce_currency', true)) {
        $saleprice = $price;
    }

    return $saleprice;
}

if (!is_admin()) {
    add_filter('woocommerce_get_price_html', 'scds_change_product_html_vendor', 999, 2);
    // comment 1 2 3
    add_filter('woocommerce_cart_item_price', 'scds_change_product_cart_html', 999, 3);
    add_filter('woocommerce_cart_item_subtotal', 'scds_change_cart_item_subtotal_html', 999, 3);
    add_filter('woocommerce_cart_subtotal', 'scds_woocommerce_cart_subtotal', 999, 3);
    //add_filter('woocommerce_cart_totals_order_total_html', 'scd_woocommerce_order_amount_total');
    //comment 4
    add_filter('woocommerce_cart_totals_order_total_html', 'scds_woocommerce_cart_totals_order_total_html', 999, 1);
    add_filter('woocommerce_cart_tax_totals', 'scd_woocommerce_cart_tax_totals', 999, 2);
    add_filter('woocommerce_checkout_create_order', 'scd_woocommerce_checkout_create_order', 999, 1);
    // add_filter('woocommerce_cart_total', 'scds_woocommerce_cart_total', 999, 1);
    add_filter('woocommerce_cart_shipping_method_full_label', 'scds_woocommerce_cart_shipping_method_full_label', 10, 2);
    //remove_all_filters('wc_price',10);
     //add_filter('woocommerce_calc_shipping_tax', 'scd_woocommerce_calc_shipping_tax', 11, 3);
    // add_filter('woocommerce_calc_tax', 'custom_woocommerce_calc_tax', 10, 5);
    // add_filter( 'woocommerce_price_ex_tax_amount', 'scd_woocommerce_price_inc_tax_amount', 999,4);
}

function scd_woocommerce_price_inc_tax_amount($tax_amount, $key, $rate, $price)
{
    $currency_cart = scd_pvc_get_cart_currency(WC()->cart);
    $basecurrency = get_option('woocommerce_currency');
    $price = scd_function_convert_subtotal($price, $currency_cart, $basecurrency);
    // var_dump($price);
    $tax_amount = $price * ($rate['rate'] / 100);

    return $tax_amount;
}
function scd_woocommerce_calc_shipping_tax($taxes, $price, $rates)
{
    var_dump($taxes);

    return $taxes;
}
function custom_woocommerce_calc_tax($taxes, $price, $rates, $price_includes_tax, $deprecated)
{
    // $taxes = 268;
    // var_dump($taxes);

    return $taxes;
}
function scd_woocommerce_cart_tax_totals($tax_totals, $instance)
{
	
	
		

    // $tax_totals = 2000;
    $currency_cart = scd_pvc_get_cart_currency(WC()->cart);
    $basecurrency = get_option('woocommerce_currency');
	
		
    
    	
    $args = [
        'ex_tax_label' => false,
        'currency' => '',
        'decimal_separator' => wc_get_price_decimal_separator(),
        'thousand_separator' => wc_get_price_thousand_separator(),
        'decimals' => wc_get_price_decimals(),
        'price_format' => get_woocommerce_price_format(),
    ];

        $decimals = scd_options_get_decimal_precision();
        $args['currency'] = $currency_cart;
        $args['decimals'] = $decimals;
        // $args['price_format'] = scd_change_currency_display_format($args['price_format'], $currency_cart);
        
	if ($currency_cart !== $basecurrency) {
		
	
		
	$sub_tax = WC()->cart->get_subtotal_tax();
		
	
		
	    if(is_cart()){
		
    foreach ($tax_totals as $key => $value) {
		
	
		
		$tax_tot  = $value-> amount;
		
		
        $diff = $tax_tot - $sub_tax ; 
		
		
		
		$diff_conv = scd_function_convert_subtotal($diff, $basecurrency, $currency_cart, true);
		
		
		
		$tax_end = $sub_tax + $diff_conv  ; 
		
		
		
		$value->formatted_amount = scd_format_converted_price_to_html($tax_end, $args);
		
		$value-> amount = $tax_end ;
      
	}

    //   $value->formatted_amount = $form;
        # code...
    }
	if(is_checkout()){
		
 
		
		
    foreach ($tax_totals as $key => $value) {
		
	
		
		$tax_tot  = $value-> amount;
		
		
		 
		
		$diff_conv = scd_function_convert_subtotal($tax_tot, $basecurrency, $currency_cart, true);
		
		
		
		
		
		$value->formatted_amount = scd_format_converted_price_to_html($diff_conv, $args);
		
		$value-> amount = $diff_conv ;
        
	}

    //   $value->formatted_amount = $form;
        # code...
    }
		
	}
	
	
	return $tax_totals;
}

//add_filter( 'woocommerce_cart_tax_totals', 'scd_woocommerce_cart_tax_totals', 10, 2 );


add_filter( 'wp_kses_allowed_html', function( $allowedposttags, $context) {

    $allowedposttags['span']['basecurrency'] = true; 
    
    return $allowedposttags;

}, 10, 2);

function scd_change_price_format_html_markup($price_html, $price_formatted, $args, $unformatted_price)
{
    global $post;
    // Patch for woocommerce versions earlier than 3.4.0:
    // return the unconverted price, it will be converted by the javascript code
    global $woocommerce;
    $options = get_option('scd_currency_options', true);
    //   if(isset($options['pricesInVendorCurrency']) && !empty($options['pricesInVendorCurrency'])){
    $product = wc_get_product($post->ID);
    list($regprice, $saleprice, $currency) = scd_get_product_price($product);
    $decimals = scd_options_get_decimal_precision();
    $args['currency'] = $currency;
    $args['decimals'] = $decimals;
    $args['price_format'] = scd_pvc_change_currency_display_format($args['price_format'], $currency);
    $price_html = scd_pvc_format_converted_price_to_html($unformatted_price, $args);
    //var_dump($price_html);
    //die();
    //        return $price_html;
    //    }
    //
    return $price_html;
}

//return format used to print prices
function scd_pvc_get_price_args()
{
    $args = [
        'ex_tax_label' => false,
        'currency' => '',
        'decimal_separator' => wc_get_price_decimal_separator(),
        'thousand_separator' => wc_get_price_thousand_separator(),
        'decimals' => wc_get_price_decimals(),
        'price_format' => get_woocommerce_price_format(),
    ];
    $decimals = scd_options_get_decimal_precision();
    $args['decimals'] = $decimals;

    return $args;
}

/**
 * Function to render the item price in product page.
 *
 * @param string $price_html The text to be rendered by default
 * @param Item   $product    The product
 *
 * @return string The HTML text to be rendered
 */
function scds_change_product_html_vendor($price_html, $product)
{
    global $post;

    if ($product->get_children()) {
        $price = [];
        foreach ($product->get_children() as $variation_id) {
            list($regprice, $saleprice, $currency) = scd_get_product_price($product, $variation_id);
            if ($saleprice > 0) {
                array_push($price, $saleprice);
            } else {
                if ($regprice > 0) {
                    array_push($price, $regprice);
                }
            }
        }
        $vendor_id = get_post_field('post_author', $product->id);
        $user_curr = get_user_meta($vendor_id, 'scd-user-currency', true);
        $currency = $user_curr;
        asort($price);
        $price1 = $price[array_key_first($price)];
        $price2 = $price[array_key_last($price)];

        if ($price1) {
            if ($price1 == $price2) {
                $price_html = get_woocommerce_currency_symbol($currency).''.$price1;

                $decimals = scd_options_get_decimal_precision();
                //$price_html = '<ins>' . get_woocommerce_currency_symbol($currency).''.$saleprice. '</ins>';
                $args['currency'] = $currency; //function to define
                if ($args['currency'] == '') {
                    $args['currency'] = get_option('woocommerce_currency');
                }
                $args['decimals'] = $decimals;
                $args['price_format'] = get_woocommerce_price_format(); //scd_change_currency_display_format ($args['price_format'], $currency);
                if ($args['price_format']) {
                    // Check if variable OR UOM text exists.

                    $woo_uom_output = get_post_meta($post->ID, '_woo_uom_input', true);

                    if ($woo_uom_output) {
                        $price_html = scd_format_converted_price_to_html($price1, $args).' <span class="uom">'.esc_attr($woo_uom_output, 'woocommerce-uom').'</span>';
                    } else {
                        $price_html = scd_format_converted_price_to_html($price1, $args);
                    }

                    //$price_html = scd_format_converted_price_to_html($price1, $args);//wc_price($price1, array('currency'=> $args['currency']));
                    // //echo 'madefo';;
                }
            } else {
                $price_html = get_woocommerce_currency_symbol($currency).''.$price1.' - '.get_woocommerce_currency_symbol($currency).''.$price2;

                $decimals = scd_options_get_decimal_precision();
                $args['currency'] = $currency; //function to define
                $args['decimals'] = $decimals;
                $args['price_format'] = get_woocommerce_price_format(); //scd_change_currency_display_format ($args['price_format'], $currency);
                if ($args['price_format']) {
                    // Check if variable OR UOM text exists.

                    $woo_uom_output = get_post_meta($post->ID, '_woo_uom_input', true);

                    if ($woo_uom_output) {
                        $price_html = $price_html = scd_format_converted_price_to_html($price1, $args).' - '.scd_format_converted_price_to_html($price2, $args).' <span class="uom">'.esc_attr($woo_uom_output, 'woocommerce-uom').'</span>';
                    } else {
                        $price_html = $price_html = scd_format_converted_price_to_html($price1, $args).' - '.scd_format_converted_price_to_html($price2, $args); //scd_format_converted_price_to_html($price1, $args).' - '.scd_format_converted_price_to_html($price2, $args);//wc_price($price1, array('currency'=> $args['currency'])).' - '.wc_price($price2, array('currency'=> $args['currency']));
                    }

                    //$price_html = $price_html = scd_format_converted_price_to_html($price1, $args).' - '.scd_format_converted_price_to_html($price2, $args);//scd_format_converted_price_to_html($price1, $args).' - '.scd_format_converted_price_to_html($price2, $args);//wc_price($price1, array('currency'=> $args['currency'])).' - '.wc_price($price2, array('currency'=> $args['currency']));
                }
            }
        }
    } elseif ($product && (!$product->get_children())) {
        if ($product->get_variation_id()) {
            list($regprice, $saleprice, $currency) = scd_get_product_price($product, $product->get_variation_id());
            if ($saleprice == $regprice) {
                $decimals = scd_options_get_decimal_precision();
                // my first modification
                $price_html = '<ins>'.get_woocommerce_currency_symbol($currency).''.$saleprice.'</ins>';
                $args['currency'] = $currency; //function to define
                $args['decimals'] = $decimals;
                $args['price_format'] = get_woocommerce_price_format(); //scd_change_currency_display_format ($args['price_format'], $currency);
                if ($args['price_format']) {
                    $woo_uom_output = get_post_meta($post->ID, '_woo_uom_input', true);

                    if ($woo_uom_output) {
                        $price_html = $price_html = '<ins>'.scd_format_converted_price_to_html($saleprice, $args).'</ins>&ensp;<span class="uom">'.esc_attr($woo_uom_output, 'woocommerce-uom').'</span>';
                    } else {
                        $price_html = '<ins>'.scd_format_converted_price_to_html($saleprice, $args).'</ins>';
                    }

                    //$price_html = '<ins>' .scd_format_converted_price_to_html($saleprice, $args) . '</ins>';                    //'<ins>' .scd_format_converted_price_to_html($saleprice, $args) . '</ins>';//'<ins>' .wc_price($saleprice, array('currency'=> $args['currency'])) . '</ins>';
                }
                // echo $price_html;
            } else {
                $decimals = scd_options_get_decimal_precision();
                //	$price_html = '<ins>' . get_woocommerce_currency_symbol($currency).''.$regprice. '</ins>';
                $args['currency'] = $currency; //function to define

                $args['decimals'] = $decimals;
                $args['price_format'] = get_woocommerce_price_format(); //scd_change_currency_display_format ($args['price_format'], $args['currency']);

                if ($args['price_format']) {
                    //$price_html = '<del>' .wc_price($regprice, array('currency'=> $args['currency'])).'</del>';
                    //$price_html = $price_html . '<ins>' .wc_price($saleprice, array('currency'=> $args['currency'])).'</ins>';

                    // Check if variable OR UOM text exists.

                    $woo_uom_output = get_post_meta($post->ID, '_woo_uom_input', true);

                    if ($woo_uom_output) {
                        $price_html = '<del>'.scd_format_converted_price_to_html($regprice, $args).'</del>&ensp;';
                        $price_html = $price_html = $price_html.'<ins>'.scd_format_converted_price_to_html($saleprice, $args).'</ins>&ensp;<span class="uom">'.esc_attr($woo_uom_output, 'woocommerce-uom').'</span>';
                    } else {
                        $price_html = '<del>'.scd_format_converted_price_to_html($regprice, $args).'</del>&ensp;';
                        $price_html = $price_html.'<ins>'.scd_format_converted_price_to_html($saleprice, $args).'</ins>';
                    }

                    //$price_html = '<del>' .scd_format_converted_price_to_html($regprice, $args).'</del>';
                       //$price_html = $price_html . '<ins>' .scd_format_converted_price_to_html($saleprice, $args).'</ins>';
                } else {
                    // second intervention
                    //$price_html = '<del>' .wc_price($regprice,array('currency'=> $args['currency'])).'</del>';
                    //$price_html = $price_html . '<ins>'.wc_price($saleprice,array('currency'=> $args['currency'])) .'</ins>';// $price_html . '<ins>' .$saleprice.'</ins>';

                    // Check if variable OR UOM text exists.

                    $woo_uom_output = get_post_meta($post->ID, '_woo_uom_input', true);

                    if ($woo_uom_output) {
                        $price_html = '<del>'.scd_format_converted_price_to_html($regprice, $args).'</del>&ensp;';
                        $price_html = $price_html = $price_html.'<ins>'.scd_format_converted_price_to_html($saleprice, $args).'</ins>&ensp;<span class="uom">'.esc_attr($woo_uom_output, 'woocommerce-uom').'</span>';
                    } else {
                        $price_html = '<del>'.scd_format_converted_price_to_html($regprice, $args).'</del>&ensp;';
                        $price_html = $price_html.'<ins>'.scd_format_converted_price_to_html($saleprice, $args).'</ins>';
                    }

                    // $price_html = '<del>' .scd_format_converted_price_to_html($regprice, $args).'</del>';
                 // $price_html = $price_html . '<ins>' .scd_format_converted_price_to_html($saleprice, $args).'</ins>';
                }
            }
        } else {
            list($regprice, $saleprice, $currency) = scd_get_product_price($product);
            if ($saleprice == $regprice) {
                // Check if variable OR UOM text exists.

                $woo_uom_output = get_post_meta($post->ID, '_woo_uom_input', true);

                if ($woo_uom_output) {
                    $price_html = '<ins>'.get_woocommerce_currency_symbol($currency).''.$saleprice.'</ins>&ensp;<span class="uom">'.esc_attr($woo_uom_output, 'woocommerce-uom').'</span>';
                } else {
                    $price_html = '<ins>'.get_woocommerce_currency_symbol($currency).''.$saleprice.'</ins>';
                }

                //$price_html = '<ins>' . get_woocommerce_currency_symbol($currency).''.$saleprice. '</ins>';

                $decimals = scd_options_get_decimal_precision();
                //$price_html = '<ins>' . get_woocommerce_currency_symbol($currency).''.$saleprice. '</ins>';
                $args['currency'] = $currency; //function to define
                $args['decimals'] = $decimals;
                $args['price_format'] = get_woocommerce_price_format(); //scd_change_currency_display_format ($args['price_format'], $currency);
                if ($args['price_format']) {
                    // Check if variable OR UOM text exists.

                    $woo_uom_output = get_post_meta($post->ID, '_woo_uom_input', true);

                    if ($woo_uom_output) {
                        $price_html = '<ins>'.scd_format_converted_price_to_html($saleprice, $args).'</ins>&ensp;<span class="uom">'.esc_attr($woo_uom_output, 'woocommerce-uom').'</span>';
                    } else {
                        $price_html = '<ins>'.scd_format_converted_price_to_html($saleprice, $args).'</ins>';
                    }

                    // $price_html = '<ins>' .scd_format_converted_price_to_html($saleprice, $args) . '</ins>';//'<ins>' .wc_price($saleprice, array('currency'=> $args['currency'])) . '</ins>';
                }
            } else {
                // Check if variable OR UOM text exists.

                $woo_uom_output = get_post_meta($post->ID, '_woo_uom_input', true);

                if ($woo_uom_output) {
                    $price_html = '<del>'.get_woocommerce_currency_symbol($currency).''.$regprice.'</del>&ensp;';

                    $price_html = $price_html = $price_html.'<ins>'.get_woocommerce_currency_symbol($currency).''.$saleprice.'</ins>&ensp;<span class="uom">'.esc_attr($woo_uom_output, 'woocommerce-uom').'</span>';
                } else {
                    $price_html = '<del>'.get_woocommerce_currency_symbol($currency).''.$regprice.'</del>&ensp;';

                    $price_html = $price_html.'<ins>'.get_woocommerce_currency_symbol($currency).''.$saleprice.'</ins>';
                }

                //$price_html = '<del>' . get_woocommerce_currency_symbol($currency).''.$regprice.'</del>';

                //$price_html = $price_html . '<ins>' . get_woocommerce_currency_symbol($currency).''.$saleprice.'</ins>';

                $decimals = scd_options_get_decimal_precision();
                //$price_html = '<ins>' . get_woocommerce_currency_symbol($currency).''.$saleprice. '</ins>';
                $args['currency'] = $currency; //function to define
                $args['decimals'] = $decimals;
                $args['price_format'] = get_woocommerce_price_format(); //scd_change_currency_display_format ($args['price_format'], $currency);
                if ($args['price_format']) {
                    //$price_html = '<del>' .wc_price($regprice, array('currency'=> $args['currency'])).'</del>';
                    //$price_html = $price_html . '<ins>' .wc_price($saleprice, array('currency'=> $args['currency'])).'</ins>';

                    // Check if variable OR UOM text exists.

                    $woo_uom_output = get_post_meta($post->ID, '_woo_uom_input', true);

                    if ($woo_uom_output) {
                        $price_html = '<del>'.scd_format_converted_price_to_html($regprice, $args).'</del>&ensp;';
                        $price_html = $price_html.'<ins>'.scd_format_converted_price_to_html($saleprice, $args).'</ins>&ensp;<span class="uom">'.esc_attr($woo_uom_output, 'woocommerce-uom').'</span>';
                    } else {
                        $price_html = '<del>'.scd_format_converted_price_to_html($regprice, $args).'</del>&ensp;';
                        $price_html = $price_html.'<ins>'.scd_format_converted_price_to_html($saleprice, $args).'</ins>';
                    }

                    // $price_html = '<del>' .scd_format_converted_price_to_html($regprice, $args).'</del>';
                   //	$price_html = $price_html . '<ins>' .scd_format_converted_price_to_html($saleprice, $args).'</ins>';
                }
            }
        }
    }

    return $price_html;
}

/**
 * Function to render the item price in cart.
 *
 * @param string  $price_html    The text to be rendered by default
 * @param Item    $cart_item     The item
 * @param ItemKey $cart_item_key The item key
 *
 * @return string The HTML text to be rendered
 */
function scds_change_product_cart_html($price_html, $cart_item, $cart_item_key)
{
    //echo 66666;
    $currency_cart = scd_pvc_get_cart_currency(WC()->cart);
    $basecurrency = get_option('woocommerce_currency');
    // Get the product price from the id
    $product = wc_get_product($cart_item['product_id']);
    //echo 'madefo';

    if (!empty($product)) {
        if ($cart_item['variation_id']) {
            list($regprice, $saleprice, $currency) = scd_get_product_price($product, $cart_item['variation_id'] ?? null);

        //var_dump($product);
        } else {
            list($regprice, $saleprice, $currency) = scd_get_product_price($product);
        }

        if ($currency !== $currency_cart && $saleprice != 0) {
            //convert price in currency_cart
            //convert price from $currency to $basecurrency

            $saleprice = scd_function_convert_subtotal($saleprice, $currency, $basecurrency, true);

            if ($currency_cart !== $basecurrency) {
                $saleprice = scd_function_convert_subtotal($saleprice, $basecurrency, $currency_cart);
            }
        }

        $args = scd_pvc_get_price_args();
        $args['currency'] = $currency_cart;
        $args['price_format'] = scd_change_currency_display_format($args['price_format'], $currency_cart);
        // Create HTML
        $price_html = scd_format_converted_price_to_html($saleprice, $args);
    }

    return $price_html;
}

/**
 * Function to render the item subtotal in cart.
 *
 * @param Item    $cart_item     The item
 * @param ItemKey $cart_item_key The item key
 *
 * @return string The HTML text to be rendered
 */
function scds_change_cart_item_subtotal_html($subtotal, $cart_item, $cart_item_key)
{
    // Get the product price from the id
    $product = wc_get_product($cart_item['product_id']);
    if (!empty($product)) {
        $currency_cart = scd_pvc_get_cart_currency(WC()->cart);
        if ($cart_item['variation_id']) {
            list($regprice, $saleprice, $currency) = scd_get_product_price($product, $cart_item['variation_id'] ?? null);
        } else {
            list($regprice, $saleprice, $currency) = scd_get_product_price($product);
        }
		
		$saleprice = floatval($saleprice);
			
		$saleprice = round($saleprice, 2);
			
        $subtotal = $saleprice * $cart_item['quantity'];
        if ($currency !== $currency_cart && $saleprice != 0) {
            $saleprice = scd_function_convert_subtotal($saleprice, $currency, $basecurrency, true);
            $subtotal = $saleprice * $cart_item['quantity'];
            if ($currency_cart !== $basecurrency) {
                $saleprice = scd_function_convert_subtotal($saleprice, $currency_cart, $basecurrency, true);
				
				$saleprice = floatval($saleprice);
			
			    $saleprice = round($saleprice, 2);
				
                $subtotal = $saleprice * $cart_item['quantity'];
            }
        }
        $args = scd_pvc_get_price_args();
        $args['currency'] = $currency_cart;
        $args['price_format'] = scd_change_currency_display_format($args['price_format'], $currency_cart);
        // Create HTML
        $subtotal = scd_format_converted_price_to_html($subtotal, $args);
    }

    return $subtotal;
}

/*
 * return the currency in which the cart will be displyed
 * if products have different currencies return scd_get_target_currency()
 */

function scd_pvc_get_cart_currency($cart)
{
    $items = $cart->get_cart();

    $cart_currency = scd_get_target_currency();
    $same_curr = false;
    $diff_curr = false;
    $current_curr = '';
    foreach ($items as $cart_item) {
        $product = wc_get_product($cart_item['product_id']);
        if (!empty($product)) {
            // list($regprice, $saleprice, $currency) = scd_get_product_price($product);

            if ($cart_item['variation_id']) {
                //    var_dump(scd_get_product_price($product,$cart_item['variation_id']));
                list($regprice, $saleprice, $currency) = scd_get_product_price($product, $cart_item['variation_id'] ?? null);
            //echo 'madefo';
            } else {
                list($regprice, $saleprice, $currency) = scd_get_product_price($product);
            }

            if ($current_curr == '') {
                $current_curr = $currency;
            } else {
                if ($currency !== $current_curr) {
                    //           $same_curr=true;
                    //        }  else {
                    $diff_curr = true;
                    // echo 'ffffffffff';
                }
            }
        }
        if ($diff_curr) {
            break;
        }
    }
    if ($diff_curr == false && $current_curr !== '') {
        $cart_currency = $current_curr;
    }

    return $cart_currency;
}

function scds_woocommerce_cart_subtotal($cart_subtotal, $compound, $cart)
{
    $currency_cart = scd_pvc_get_cart_currency($cart);
    $items = $cart->get_cart();

    $mysubtot = 0;
    $basecurrency = get_option('woocommerce_currency');

    foreach ($items as $cart_item) {
        // Get the product price from the id
        $product = wc_get_product($cart_item['product_id']);
        if (!empty($product)) {
            if ($cart_item['variation_id']) {
                //    var_dump(scd_get_product_price($product,$cart_item['variation_id']));
                list($regprice, $saleprice, $currency) = scd_get_product_price($product, $cart_item['variation_id'] ?? null);
            //echo 'madefo';
            } else {
                list($regprice, $saleprice, $currency) = scd_get_product_price($product);
            }
            if ($currency !== $currency_cart && $saleprice != 0) {
                //convert price in currency_cart
                //convert price from $currency to $basecurrency
                $saleprice = scd_function_convert_subtotal($saleprice, $currency, $basecurrency, true);

                if ($currency_cart !== $basecurrency) {
                    $saleprice = scd_function_convert_subtotal($saleprice, $basecurrency, $currency_cart);
                }
            }
            $qty = $cart_item['quantity'];
			
			$saleprice = floatval($saleprice);
			
			$saleprice = round($saleprice, 2);

            // Add the item price to our computed subtotal
            $unit_price = $saleprice * $qty;
            $mysubtot += $unit_price;
        }
    }
    $args = scd_pvc_get_price_args();
    $args['currency'] = $currency_cart;
    $args['price_format'] = scd_change_currency_display_format($args['price_format'], $currency_cart);
    // Create HTML
		
    $cart_subtotal = scd_format_converted_price_to_html($mysubtot, $args);

    //var_dump($currency);
    return $cart_subtotal;
}

//apply_filters( 'woocommerce_cart_shipping_method_full_label', $label, $method );
function scds_woocommerce_cart_shipping_method_full_label($label, $method)
{
    $currency_cart = scd_pvc_get_cart_currency(WC()->cart);
    $items = WC()->cart->get_cart();
    $basecurrency = get_option('woocommerce_currency');

    $label = $method->get_label();
    $has_cost = 0 < $method->cost;
    $hide_cost = !$has_cost && in_array($method->get_method_id(), ['free_shipping', 'local_pickup'], true);

    $args = scd_pvc_get_price_args();
    $args['currency'] = $currency_cart;
    $args['price_format'] = scd_change_currency_display_format($args['price_format'], $currency_cart);

    if ($has_cost && !$hide_cost) {
        if (WC()->cart->display_prices_including_tax()) {
            $costs = $method->cost + $method->get_shipping_tax();
            if ($currency_cart !== $basecurrency) {
                $costs = scd_function_convert_subtotal($costs, $basecurrency, $currency_cart);
            }

            // Create HTML
            $ship_cost = scd_format_converted_price_to_html($costs, $args);
            $label .= ': '.$ship_cost;
            if ($method->get_shipping_tax() > 0 && !wc_prices_include_tax()) {
                $label .= ' <small class="tax_label">'.WC()->countries->inc_tax_or_vat().'</small>';
            }
        } else {
            $costs = $method->cost;
            if ($currency_cart !== $basecurrency) {
                $costs = scd_function_convert_subtotal($costs, $basecurrency, $currency_cart);
				
            }
            // Create HTML
            $ship_cost = scd_format_converted_price_to_html($costs, $args);
            //$label .= ': ' . wc_price( $method->cost );
            $label .= ': '.$ship_cost;
            if ($method->get_shipping_tax() > 0 && wc_prices_include_tax()) {
                $label .= ' <small class="tax_label">'.WC()->countries->ex_tax_or_vat().'</small>';
            }
        }
    }

    return $label;
}

/*
 * cart total//order amount
*/

function scds_woocommerce_cart_totals_order_total_html($total)
{
    //get cart currency
    $currency_cart = scd_pvc_get_cart_currency(WC()->cart); ?> 
    <input type="hidden" class="curr_cart" value="<?php echo $currency_cart; ?>">
    <?php
    $custom_symbol = get_woocommerce_currency_symbol($currency_cart); ?> 
    <input type="hidden" class="curr_symb_cart" value="<?php echo $custom_symbol; ?>">
    <?php

    if (function_exists('scd_get_currency_override_options')) {
        if (scd_get_currency_override_options($currency_cart)) {
            $custom_symbol = scd_get_currency_override_options($currency_cart)['sym'];
        }
    } ?>
        <script>
            jQuery('document').ready(()=>{
                // elmt = jQuery('.tax-rate').find('.woocommerce-Price-currencySymbol'); 
                // for(i=0;i<elmt.length; i++){
                //     jQuery(elmt[i]).html('<?php echo $custom_symbol; ?>');
                // }
                // elmnt = jQuery('.woocommerce-shipping-methods').find('.woocommerce-Price-currencySymbol'); 
                // for(i=0;i<elmnt.length; i++){
                //     jQuery(elmnt[i]).html('<?php //echo $custom_symbol;?>');
                // }
            });
        </script>
    <?php
    $items = WC()->cart->get_cart();

    $mysubtot = 0;
    $basecurrency = get_option('woocommerce_currency'); ?> 
    <input type="hidden" class="woo_curr" value="<?php echo $basecurrency; ?>">
    <?php
    $args = scd_pvc_get_price_args();
    $args['currency'] = $currency_cart;
    $args['price_format'] = scd_change_currency_display_format($args['price_format'], $currency_cart);
    foreach ($items as $cart_item) {
        // Get the product price from the id
        $product = wc_get_product($cart_item['product_id']);
        if (!empty($product)) {
            if ($cart_item['variation_id']) {
                list($regprice, $saleprice, $currency) = scd_get_product_price($product, $cart_item['variation_id'] ?? null);
            } else {
                list($regprice, $saleprice, $currency) = scd_get_product_price($product);
            }
            if ($currency !== $currency_cart && $saleprice != 0) {
                //convert price in currency_cart
                //convert price from $currency to $basecurrency

                $saleprice = scd_function_convert_subtotal($saleprice, $currency, $basecurrency, true);

                if ($currency_cart !== $basecurrency) {
                    $saleprice = scd_function_convert_subtotal($saleprice, $basecurrency, $currency_cart);
                }
            }
            $qty = $cart_item['quantity'];
			
			$saleprice = floatval($saleprice);
			
			$saleprice = round($saleprice, 2);

            // Add the item price to our computed subtotal
            $unit_price = $saleprice * $qty;
            $mysubtot += $unit_price;
        }
    }

    // If prices are tax inclusive, show taxes here.
    //if (wc_tax_enabled() && WC()->cart->display_prices_including_tax()) {
    if (wc_tax_enabled()) {
        $tax_saver = 0;
        $tax_string_array = [];
        $cart_tax_totals = WC()->cart->get_tax_totals();
        foreach ($cart_tax_totals as $code => $tax) {
            $tax_amount = $tax->amount;
            $tax_saver += $tax_amount;
            if ($currency_cart !== $basecurrency) {
                $tax_amount = $tax_amount;
            }
            $tax_html = scd_format_converted_price_to_html($tax_amount, $args);
            $tax_string_array[] = sprintf('%s %s', "$tax_html", $tax->label);
        }
        if (get_option('woocommerce_tax_total_display') == 'itemized') {
            foreach ($cart_tax_totals as $code => $tax) {
                $tax_amount = $tax->amount;
                $tax_saver += scd_function_convert_subtotal($tax_amount, $basecurrency, $currency_cart);
                if ($currency_cart !== $basecurrency) {
                    // $tax_amount = scd_function_convert_subtotal($tax_amount, $basecurrency, $currency_cart);
                }
                $tax_html = scd_format_converted_price_to_html($tax_amount, $args);
                // $tax_string_array[] = sprintf('%s %s', $tax_html, $tax->label);
                // var_dump($tax_amount);
            }
        } elseif (!empty($cart_tax_totals)) {
            $tax_amount = WC()->cart->get_taxes_total(true, true);
			var_dump($tax_amount);
            if ($currency_cart !== $basecurrency) {
                // $tax_amount = scd_function_convert_subtotal($tax_amount, $basecurrency, $currency_cart);
            }
            $tax_html = scd_format_converted_price_to_html($tax_amount, $args);

            $tax_string_array[] = sprintf('%s %s', $tax_html, WC()->countries->tax_or_vat());
        }

        if (!empty($tax_string_array)) {
            $taxable_address = WC()->customer->get_taxable_address();
            /* translators: %s: country name */
            $estimated_text = WC()->customer->is_customer_outside_base() && !WC()->customer->has_calculated_shipping() ? sprintf(' '.__('estimated for %s', 'woocommerce'), WC()->countries->estimated_for_prefix($taxable_address[0]).WC()->countries->countries[$taxable_address[0]]) : '';
            /* translators: %s: tax information */
            //$value .= '<small class="includes_tax">' . sprintf( __( '(includes %s)', 'woocommerce' ), implode( ', ', $tax_string_array ) . $estimated_text ) . '</small>';
        }
    }
    //get shipping fees
    $ship_total = WC()->cart->get_shipping_total(); 
    if ($currency_cart !== $basecurrency) {
        $ship_total = scd_function_convert_subtotal($ship_total, $basecurrency, $currency_cart);
		
        // echo $ship_total;
    }

	
    $total_amount = $mysubtot + $ship_total + $tax_amount;

	
    $total = scd_format_converted_price_to_html($total_amount, $args);
  
    $decimal_precision_ = wc_get_price_decimals(); ?> 
    <input type="hidden" class="decimal_precision" value="<?php echo $decimal_precision_; ?>">
    <?php

    return $total;
}

/* calculate shipping total */

//add_filter('woocommerce_cart_shipping_method_full_label', 'scd_woocommerce_package_rates', 999, 2);
function scd_woocommerce_package_rates($label, $method)
{
    $currency_cart = scd_pvc_get_cart_currency(WC()->cart);
    $basecurrency = get_option('woocommerce_currency');
    $args = scd_pvc_get_price_args();
    $args['currency'] = $currency_cart;
    $args['price_format'] = scd_change_currency_display_format($args['price_format'], $currency_cart);
    $label = $method->get_label();
    $has_cost = 0 < $method->cost;
    $hide_cost = !$has_cost && in_array($method->get_method_id(), ['free_shipping', 'local_pickup'], true);

    if ($has_cost && !$hide_cost) {
        if (WC()->cart->display_prices_including_tax()) {
            if ($currency_cart !== $basecurrency) {
                $method->cost = scd_function_convert_subtotal($method->cost, $basecurrency, $currency_cart);
                $costs = $method->cost + $method->get_shipping_tax();
                $label .= ': '.scd_format_converted_price_to_html($costs, $args);
                if ($method->get_shipping_tax() > 0 && !wc_prices_include_tax()) {
                    $label .= ' <small class="tax_label">'.WC()->countries->inc_tax_or_vat().'</small>';
                }
            }
            // $ship_cost = scd_con
            // $label .= ': ' . wc_price( $method->cost + $method->get_shipping_tax() );
        } else {
            if ($currency_cart !== $basecurrency) {
                $method->cost = scd_function_convert_subtotal($method->cost, $basecurrency, $currency_cart);
                $costs = $method->cost;
                $label .= ': '.scd_format_converted_price_to_html($costs, $args);
                // $label .= ': ' . wc_price( $method->cost );
                // var_dump($method->cost);
                if ($method->get_shipping_tax() > 0 && wc_prices_include_tax()) {
                    $label .= ' <small class="tax_label">'.WC()->countries->ex_tax_or_vat().'</small>';
                }
            }
        }
    }
    // var_dump($method);
    return $label;
}

function scd_woocommerce_checkout_create_order($order)
{
	// Save the payment method in the Session object
        
	add_filter( 'woocommerce_currency', 'filter_woocommerce_currency', 10, 1 );
	
    $currency_cart = scd_pvc_get_cart_currency(WC()->cart);
    $basecurrency = get_option('woocommerce_currency');
    ////////////////
    $cart_total = 0;
    foreach ($order->get_items() as $item_id => $item) {
        $product = $item->get_product();
        list($regprice, $saleprice, $currency) = scd_get_product_price($product);
        $product_quantity = (int) $item->get_quantity(); // product Quantity
        // The new line item price
        $new_line_item_price = $saleprice * $product_quantity;
        if ($currency !== $currency_cart) {
            //convert price in currency_cart
            //convert price from $currency to $basecurrency
            $saleprice = scd_function_convert_subtotal($saleprice, $currency, $basecurrency, true);

            $new_line_item_price = $saleprice * $product_quantity;

            if ($currency_cart !== $basecurrency) {
                $saleprice = scd_function_convert_subtotal($saleprice, $basecurrency, $currency_cart);
                $new_line_item_price = $saleprice * $product_quantity;
            }
        }

        // Set the new price
        $item->set_subtotal($new_line_item_price);
        $item->set_total($new_line_item_price);

        $cart_total = $cart_total + $new_line_item_price;
        // Make new taxes calculations
        $item->calculate_taxes();

        $item->save(); // Save line item data
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $fees_total = 0;
    $shipping_total = 0;
    $cart_subtotal_tax = 0;
    $cart_total_tax = 0;

    $cart_subtotal = $cart_total; //WC()->cart->get_subtotal();//$order->get_cart_subtotal_for_order();
    //$cart_total = WC()->cart->get_total();//$order->get_cart_total_for_order();

    // Sum shipping costs.
    foreach ($order->get_shipping_methods() as $shipping) {
        $shipping_total += round($shipping->get_total(), wc_get_price_decimals());
        if ($currency_cart !== $basecurrency) {
            $shipping_price = scd_function_convert_subtotal($shipping->get_total(), $basecurrency, $currency_cart);
            $shipping->set_total($shipping_price);
        }
    }
    if ($currency_cart !== $basecurrency) {
        $shipping_total = scd_function_convert_subtotal($shipping_total, $basecurrency, $currency_cart);
    }
    $order->set_shipping_total($shipping_total);

    // Sum fee costs.
    foreach ($order->get_fees() as $item) {
        $fee_total = $item->get_total();

        if (0 > $fee_total) {
            $max_discount = round($cart_total + $fees_total + $shipping_total, wc_get_price_decimals()) * -1;

            if ($fee_total < $max_discount && 0 > $max_discount) {
                $item->set_total($max_discount);
            }
        }
        $fees_total += $item->get_total();
    }

    // Calculate taxes for items, shipping, discounts. Note; this also triggers save().
    $order->calculate_taxes();

    // Sum taxes again so we can work out how much tax was discounted. This uses original values, not those possibly rounded to 2dp.
    foreach ($order->get_items() as $item) {
        $taxes = $item->get_taxes();

        foreach ($taxes['total'] as $tax_rate_id => $tax) {
            $cart_total_tax += (float) $tax;
        }

        foreach ($taxes['subtotal'] as $tax_rate_id => $tax) {
            $cart_subtotal_tax += (float) $tax;
        }
    }

    //    $order->set_discount_total($cart_subtotal - $cart_total);
    //    $order->set_discount_tax(wc_round_tax_total($cart_subtotal_tax - $cart_total_tax));

    $order->set_total(round($cart_total + $fees_total + $order->get_shipping_total() + $order->get_cart_tax() + $order->get_shipping_tax(), wc_get_price_decimals()));

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //$order->calculate_totals();

    //    $ship_cost = scd_function_convert_subtotal($order->get_shipping_total(), $order->get_currency(), $currency_cart);
    //    $order->set_shipping_total($ship_cost);
    //start caluclate
    //$order->set_total( round( $cart_total + $fees_total + $shipping_total() + $order->get_cart_tax() + $shipping_tax(), wc_get_price_decimals() ) );
    //do_action( 'woocommerce_order_after_calculate_totals', $and_taxes, $this );
    // Make the calculations  for the order
    //$order->save(); // Save and sync the data
    // Update the order curency
    $order->set_currency($currency_cart);

    // Recaclculate order totals
    //$order->calculate_totals();

    ///////////////////
    return $order;
}


    
function filter_woocommerce_currency( $get_option ) {
     
    if ( scd_pvc_get_cart_currency(WC()->cart) != ""){	 
     
	 $currency_cart = scd_pvc_get_cart_currency(WC()->cart);
	 
     $get_option = $currency_cart ;
	}
	 
    return $get_option; 
} 
         

add_action('woocommerce_single_product_lightbox_summary', 'breakwoocommerce_template_single_price', 10);
function breakwoocommerce_template_single_price()
{
    global $product;
    list($regprice, $saleprice, $currency) = scd_get_product_price($product);
    if (function_exists('scd_get_currency_override_options')) {
        $custom_options = scd_get_currency_override_options($currency)['sym'];
    }
    if (!$custom_options) {
        $custom_options = $currency;
    } ?>
    <script>
        jQuery('document').ready(()=>{
            let single_var_price = ()=>{
                const inter = setInterval(()=>{
                let var_elements = jQuery('.single_variation_wrap').find('.woocommerce-Price-currencySymbol');
                    if(var_elements.length>0){
                        for(let i=0; i < var_elements.length; i++){
                            console.log(var_elements[i].innerHTML);
                            var_elements[i].innerHTML = '<?php echo $custom_options; ?>';
                        }    
                        clearInterval(inter);
                    }else{
                        clearInterval(var_elements);
                    } 
                },10);
            }
            
            elements = jQuery('.product-quick-view-container').find('.woocommerce-Price-currencySymbol');
            
            for(let i=0; i < elements.length; i++){
            
                elements[i].innerHTML = '<?php echo $custom_options; ?>';
            
                
            }
            
            jQuery('#pa_size').change(function(){
                const inter = setInterval(()=>{
                    let var_elements = jQuery('.single_variation_wrap').find('.woocommerce-Price-currencySymbol');
                        if(var_elements.length>0){
                            for(let i=0; i < var_elements.length; i++){
                                console.log(var_elements[i].innerHTML);
                                var_elements[i].innerHTML = '<?php echo $custom_options; ?>';
                            }    
                            clearInterval(inter);
                        }else{
                            clearInterval(var_elements);
                        } 
                    },10);
                }
            );
            
            jQuery('#var').change(single_var_price());
        })
    </script>
    <?php
}

     


